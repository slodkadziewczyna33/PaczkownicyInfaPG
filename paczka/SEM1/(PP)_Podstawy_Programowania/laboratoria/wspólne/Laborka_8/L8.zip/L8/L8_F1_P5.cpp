#include <stdlib.h>
#include <stdio.h>
#include <math.h>
const double precyzja = 1./(1<<20);
struct punkt{
	double x;
	double y;
	double z;
};

double odleglosc(struct punkt a){
	return sqrt(a.x*a.x+a.y*a.y+a.z*a.z);
}

int por(const void *a, const void *b){
	double od_a = odleglosc(*(struct punkt*)a), od_b = odleglosc(*(struct punkt*)b);
	if(abs(od_a - od_b) < precyzja) return 0;
	else if(od_a - od_b > 0) return 1;
	else return -1;
}

struct punkt losuj(){
	struct punkt a;
	a.x = (double)rand()/sqrt((double)RAND_MAX);
	a.y = (double)rand()/sqrt((double)RAND_MAX);
	a.z = (double)rand()/sqrt((double)RAND_MAX);
	return a;
}

struct punkt losuj2(){
	struct punkt a;
	a.x = rand()%10;
	a.y = rand()%10;
	a.z = rand()%10;
	return a;
}

int main(){
	struct punkt *tablica;
	struct punkt *temp;
	int rozmiar = 100;
	tablica = (struct punkt*) malloc(sizeof(struct punkt) * rozmiar);
	for(temp = tablica; temp < tablica+rozmiar; temp++) 
		*temp = losuj2();

	for(temp = tablica; temp < tablica+rozmiar; temp++) 
		printf("%lf %lf %lf\n", temp->x, temp->y, temp->z); 
	printf("\n\n");
	qsort(tablica, rozmiar, sizeof(struct punkt), por); 

	for(temp = tablica; temp < tablica+rozmiar; temp++) 
		printf("%lf %lf %lf\n", temp->x, temp->y, temp->z); 
	free(tablica);
	return 0;
}