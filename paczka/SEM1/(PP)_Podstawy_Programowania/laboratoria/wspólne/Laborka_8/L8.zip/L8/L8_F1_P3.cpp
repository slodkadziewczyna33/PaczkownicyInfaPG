#include<iostream>

using namespace std;

struct osoba{
	char *imie;
	char *nazwisko;
	int rok_urodzenia;
};

/** Funkcja sortuje adresy struktur z tablicy adres�w struktur typu osoba*/
int sortuj(osoba **tablica, int liczba){
	int i, j;
	osoba *temp;
	for(i = 0; i < liczba; i++)
		for(j = 0; j < liczba; j++)
			if( tablica[i]->rok_urodzenia > tablica[j]->rok_urodzenia){
				temp = tablica[i];
				tablica[i] = tablica[j];
				tablica[j] = temp;
			}
	return 0;
}

/** Funkcja wypisuje elementy tablicy, kt�ra zawiera struktury osoba*/
int wypisz(osoba *tablica, int liczba){
	while(liczba--){
		cout << tablica->imie << " " << tablica->nazwisko;
cout << " " << tablica->rok_urodzenia << endl;
		tablica++;
	}
	return 0;
}

/** Funkcja wypisuje struktury, kt�rych adresy zawiera tablica*/
int wypisz_wsk(osoba **tablica, int liczba){
	while(liczba--){
		cout << (*tablica)->imie << " " << (*tablica)->nazwisko << " " << (*tablica)->rok_urodzenia << endl;
		tablica++;
	}
	return 0;
}

int main(){
	struct osoba dane[4] = {{"Antoni", "Adamski", 1985},{"Bartosz", "Barbarski",1972},{"Celina","Cezarska",1992}};
	dane[3].imie = "Dominik";
	dane[3].nazwisko = "Danucki";
	wypisz(dane, 4);
	struct osoba **dane_wsk = new struct osoba*[4];
	for(int i = 0; i < 4; i++) dane_wsk[i] = dane + i; //Przepisywanie adres�w tablicy adres�w
	sortuj(dane_wsk,4);
	wypisz_wsk(dane_wsk,4);
	return 0;
}